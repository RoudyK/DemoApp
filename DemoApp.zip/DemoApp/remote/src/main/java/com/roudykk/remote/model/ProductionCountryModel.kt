package com.roudykk.remote.model

data class ProductionCountryModel(
        var iso_3116_1: String?= null,
        var name: String?= null)