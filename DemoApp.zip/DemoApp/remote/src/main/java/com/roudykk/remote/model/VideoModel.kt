package com.roudykk.remote.model

data class VideoModel(
        var id: String,
        var iso_639_1: String,
        var key: String,
        var name: String,
        var site: String,
        var size: String,
        var type: String)