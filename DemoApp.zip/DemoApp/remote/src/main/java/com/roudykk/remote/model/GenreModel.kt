package com.roudykk.remote.model

data class GenreModel(
        var id: Int? = null,
        var name: String? = null)