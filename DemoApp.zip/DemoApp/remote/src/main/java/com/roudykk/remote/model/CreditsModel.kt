package com.roudykk.remote.model

data class CreditsModel(
        var cast: List<PersonModel>? = null,
        var crew: List<PersonModel>? = null)