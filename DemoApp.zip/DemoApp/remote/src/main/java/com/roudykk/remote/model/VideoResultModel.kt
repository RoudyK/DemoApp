package com.roudykk.remote.model

data class VideoResultModel(var results: List<VideoModel>? = null)