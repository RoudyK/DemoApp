package com.roudykk.remote.model

data class SpokenLanguageModel(
        var iso_639_1: String? = null,
        var name: String? = null)