package com.roudykk.remote.model

class ReviewModel(var id: String,
                  var author: String,
                  var content: String,
                  var url: String)