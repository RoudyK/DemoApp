package com.roudykk.domain.model

data class Video(
        var id: String,
        var isoName: String,
        var key: String,
        var name: String,
        var site: String,
        var size: String,
        var type: String)