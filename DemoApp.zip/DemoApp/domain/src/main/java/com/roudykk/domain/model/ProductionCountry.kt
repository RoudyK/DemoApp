package com.roudykk.domain.model

data class ProductionCountry(
        var isoName: String? = null,
        var name: String? = null)