package com.roudykk.domain.model

class Review(var id: String,
             var author: String,
             var content: String,
             var url: String)