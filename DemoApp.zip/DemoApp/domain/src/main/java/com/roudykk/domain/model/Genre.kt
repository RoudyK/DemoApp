package com.roudykk.domain.model

data class Genre(var id: Int? = null,
                 var name: String? = null)