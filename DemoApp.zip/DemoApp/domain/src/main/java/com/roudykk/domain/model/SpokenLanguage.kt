package com.roudykk.domain.model

data class SpokenLanguage(
        var isoName: String? = null,
        var name: String? = null)