package com.roudykk.data.mapper

import org.junit.Test

interface EntityMapperTest {

    @Test
    fun mapFromEntity()

    @Test
    fun mapToEntity()
}