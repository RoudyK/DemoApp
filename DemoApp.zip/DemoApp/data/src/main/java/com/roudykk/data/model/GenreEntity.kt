package com.roudykk.data.model

data class GenreEntity(var id: Int? = null,
                       var name: String? = null)