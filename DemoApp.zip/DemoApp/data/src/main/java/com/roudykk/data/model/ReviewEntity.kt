package com.roudykk.data.model

class ReviewEntity(var id: String,
                   var author: String,
                   var content: String,
                   var url: String)