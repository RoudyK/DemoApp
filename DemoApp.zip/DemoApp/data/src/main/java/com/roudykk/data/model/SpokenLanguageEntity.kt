package com.roudykk.data.model

data class SpokenLanguageEntity(
        var isoName: String? = null,
        var name: String? = null)