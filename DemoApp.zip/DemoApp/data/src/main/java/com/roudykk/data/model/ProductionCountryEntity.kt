package com.roudykk.data.model

data class ProductionCountryEntity(var isoName: String? = null,
                                   var name: String? = null)