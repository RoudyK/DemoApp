package com.demo.roudykk.demoapp.extensions;

import com.airbnb.epoxy.EpoxyController;

public interface ModelsBuilder {
    void build(EpoxyController epoxyController);
}
