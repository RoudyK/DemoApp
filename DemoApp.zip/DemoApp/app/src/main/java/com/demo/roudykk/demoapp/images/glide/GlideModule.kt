package com.demo.roudykk.demoapp.images.glide

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/*
Used to generate the GlideApp class
 */
@GlideModule
class GlideModule : AppGlideModule()