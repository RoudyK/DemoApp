@EpoxyDataBindingPattern(rClass = R.class, layoutPrefix = "item")
package com.demo.roudykk.demoapp.databinding;

import com.airbnb.epoxy.EpoxyDataBindingPattern;
import com.demo.roudykk.demoapp.R;