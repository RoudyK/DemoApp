package com.demo.roudykk.demoapp.db

class PreferenceRepo {
    companion object {
        const val PREFERENCE_DARK_THEME = "PREFERENCE_DARK_THEME"
    }
}