package com.roudykk.presentation.state

enum class ResourceState {
    LOADING, SUCCESS, ERROR
}